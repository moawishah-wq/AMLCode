# Changelog

## 1.0.0, 2026-07-26

- Made the verification suite generate fresh outputs automatically in a temporary
  directory; manuscript checks can no longer be silently skipped.
- Expanded verification to cover every displayed numerical quantity in the three examples,
  all declared output files, CSV/JSON consistency, structural dimensions, and release
  metadata.
- Renamed Table 2 export columns to `exact_ambient_measure` and
  `ball_ambient_measure`, avoiding the use of “area” for the three-dimensional consensus
  example.
- Replaced the stale `verify.py` comment with the correct `test_reproduce.py` reference.
- Added an exact tested-environment lock file and documented Python/package versions.
- Set release metadata to version `1.0.0` and date `2026-07-26`.
- Replaced Rahul Mahapatra with Muhammad Hagui and updated the affiliation to
  Woodbridge Senior High School, Woodbridge, VA, USA.
